/*A program that get the data from the ewallet
 *Author:  LinJianHua 2024051604112 (linhuaabcdefg@163.com)      2025-12-05
 *Last modified: 2025-12-05 13:37:59
 */
import std;
using std::string;
using std::vector;
using std::ifstream;
using std::istringstream;
using std::getline;
using std::istream;
using std::print;
using std::runtime_error;
using std::invalid_argument;
using CNY = double;
using Gender = std::string;

struct Summary{
    int incomeAmount;
    CNY incomes;
    int payAmount;
    CNY pays;
    CNY netBalance;
};
struct MonthlyStatement{
    int month;
    vector<double> transactions;
    Summary summary;
};
struct Account{
    string name;
    Gender male;
    int age;
    vector<MonthlyStatement> monthlyStatement;
    int currentBalance;
};


//重载运算符，为read函数中iss >> g做准备
//注意形参为istream&类型时，实参可以为istringstream 类型，
istringstream& operator>>(istringstream& is, MonthlyStatement& month);

void read(Account& ac)
{
    print("Reading all transactions of all months  from a file... \n");
    ifstream ifs("../../ewallet.dat");
    if(!ifs) throw runtime_error("fail to open file");

    string line; istringstream iss;
    if(getline(ifs, line)){
        iss.str(line);
        iss >> ac.name >> ac.male >> ac.age >> ac.currentBalance;
        if(iss.fail()){
            print("fail to read the owner!\n");
            iss.clear();//清除错误读取导致的fail状态
        }else{
            print("reading the owner Done!\n");
            iss.clear();//注意正常读取结束只会设置eof不设置fail
                         //所以还要加个else清除正常读取结束后的eof状态
        }
    }
    //使用getline加istringsream作为中间人来读取 而 不直接使用ifs>>，
    //是为了使读取ifs的某行失败时不影响读取ifs的其他行
    while(getline(ifs, line)){  // std::getline返回ifs
        iss.str(line);          // 将流iss的缓冲区内容设置为字符串line但不会重置流的状态标志
        MonthlyStatement g;  //这里创建什么类型的对象取决于文件中重复出现的对象是什么：单月的账单！！！
        if(iss >> g) ac.monthlyStatement.emplace_back(g);
        else iss.clear();
    }

    if(ifs.eof()) print("Reading done!\n\n");

}

istringstream& operator>>(istringstream& is, MonthlyStatement& month){
    print("  Reading data of a month... \n");
    if(is){
        is >> month.month;
        double value;
        while(is >> value){
            month.transactions.emplace_back(value);
        }
        if(!is.eof() && is.fail()){//非正常读取结束
            print("this month has Incorrect transaction!\n");
            is.clear();//这里若不清除错误状态会使得72行中不会将该月整个账单加入集合中，所以必须clear
        }else{
            print("reading data of a month Done. \n");
            is.clear();
        }
    }
    return is;
}
