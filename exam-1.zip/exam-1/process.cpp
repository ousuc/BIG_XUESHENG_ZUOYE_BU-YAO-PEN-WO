/*A program that process the data of bill
 *Author:  LinJianHua 2024051604112 (linhuaabcdefg@163.com)      2025-12-05
 *Last modified: 2025-12-05 13:40:31
 */
import std;
using std::string;
using std::vector;
using std::print;
using CNY = double;
using Gender = std::string;
struct Summary{
    int incomeAmount;
    CNY incomes;
    int payAmount;
    CNY pays;
    CNY netBalance;
};
struct MonthlyStatement{
    int month;
    vector<double> transactions;
    Summary summary;
};
struct Account{
    string name;
    Gender male;
    int age;
    vector<MonthlyStatement> monthlyStatement;
    int currentBalance;
};
void computeSort(Account& ac)
{
    print("Processing all transactions of every month... \n");
    for(MonthlyStatement& single: ac.monthlyStatement){
        vector<double>zheng;
        vector<double>fu;
        for(auto& value: single.transactions){
            if(value >=0) zheng.emplace_back(value);
            else fu.emplace_back(value);
        }
        single.summary.incomeAmount=zheng.size();
        single.summary.payAmount=fu.size();
        single.summary.incomes=0;
        single.summary.pays=0;
        for(auto& a:zheng) single.summary.incomes+= a;
        for(auto& b:fu) single.summary.pays+= b;
        single.summary.netBalance=single.summary.incomes-single.summary.pays;
    }
    //函数原型：1.  void stable_sort(迭代器1, 迭代器2);
    //        2.  void stable_sort( 迭代器1, 迭代器2, 比较函数对象);
//奇怪的是我发现我没有加std::也能正常编译？？？？GongWei用的是std::ranges::stable_sort;不是我这个函数，我看错了难怪之前老报错参数有问题
    stable_sort(ac.monthlyStatement.begin(),ac.monthlyStatement.end(), [](auto& g1, auto& g2){
        return g1.summary.netBalance < g2.summary.netBalance;
    });
    print("Processing done!\n\n");
}

