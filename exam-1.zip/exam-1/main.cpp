/*A program that
 *Author:  LinJianHua 2024051604112 (linhuaabcdefg@163.com)      2025-12-05
 *Last modified: 2025-12-05 13:33:42
 */
import std;
using std::string;
using std::vector;
using CNY = double;
using Gender = std::string;
using std::exception;
using std::print;

struct Summary{
    int incomeAmount;
    CNY incomes;
    int payAmount;
    CNY pays;
    CNY netBalance;
};
struct MonthlyStatement{
    int month;
        vector<double> transactions;
    Summary summary;
};
struct Account{
    string name;
    Gender male;
    int age;
    vector<MonthlyStatement> monthlyStatement;
    int currentBalance;
};
extern void read(Account& ac);
extern void computeSort(Account& ac);
extern void print(Account& ac);
int main()
{
    Account ac;
    try{
        read(ac);
        computeSort(ac);
        print(ac);
    }catch(const std::exception& e){
        print("error: {}\n", e.what());
    } catch (...) {
        print("Other error!\n");
    }
    return 0;
}
