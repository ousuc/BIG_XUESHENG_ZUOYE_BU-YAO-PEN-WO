/*A program that print the data of account
 *Author:  LinJianHua 2024051604112 (linhuaabcdefg@163.com)      2025-12-05
 *Last modified: 2025-12-05 13:39:37
 */
import std;
using std::string;
using std::vector;
using std::print;
using CNY = double;
using Gender = std::string;
struct Summary{
    int incomeAmount;
    CNY incomes;
    int payAmount;
    CNY pays;
    CNY netBalance;
};
struct MonthlyStatement{
    int month;
    vector<double> transactions;
    Summary summary;
};
struct Account{
    string name;
    Gender male;
    int age;
    vector<MonthlyStatement> monthlyStatement;
    int currentBalance;
};
void print(Account& ac){
    print("Ewallet account: {}  {}  Age:{} CurrentBalance: {}\n",ac.name,ac.male,ac.age,ac.currentBalance);
    print("Account Currrncy: CNY  Calendar Year 2025\n");
    print("monthly Transactions:\n");
    for(auto &month: ac.monthlyStatement){
        print("{}  netBalance:{:.5}\n ",month.month,month.summary.netBalance);
        print("     transactions:");
        for(auto& value:month.transactions){
            print(" {} ",value);
        }
        print("\n");
    }
}
